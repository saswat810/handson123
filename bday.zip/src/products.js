const products = [
  {
    _id: '1',
    description: "Hope all your birthday wishes come true",
    image: '/images/img_1.jpg',

  },
  {
    _id: '2',

    image: '/images/img_2.jpg',
    description:
    "Its your special day - get out there and celebrate!"
  },
  {
    _id: '3',
    image: '/images/img_3.jpg',
    description:
      'Wishing you the biggest slice of happy today.',

  },
  {
    _id: '4',
    image: '/images/img_4.jpg',
    description:
      'I hope your celebration gives you many happy memories!',
  },
  {
    _id: '5',
    image: '/images/img_5.jpg',
    description:
      'Our age is merely the number of years the world has been enjoying us! ',

  },
  {
    _id: '6',
    image: '/images/img_6.jpg',
    description:
      'Happy birthday to someone who is forever young!',
  },
]

export default products
